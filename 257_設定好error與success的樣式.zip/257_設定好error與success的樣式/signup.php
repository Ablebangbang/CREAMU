<?php require "header.php"; ?>

  <main class="signup-form">
    <h1>註 冊</h1>
    <?php
    
        if (isset($_GET["error"])) {
            
            if ($_GET["error"] == "emptyfields") {
                
                echo "<p class='error-message'>請輸入完整的信息!</p>";
                
                
            } elseif ($_GET["error"] == "invalidmail") {
                
                echo "<p class='error-message'>請輸入正確的郵箱!</p>";
                
            } elseif ($_GET["error"] == "passwordcheck") {
                
                echo "<p class='error-message'>請輸入相同的密碼!</p>";
                
            } elseif ($_GET["error"] == "sqlerror") {
                
                echo "<p class='error-message'>數據庫連結失敗!</p>";
                
            } elseif ($_GET["error"] == "usertaken") {
                
                echo "<p class='error-message'>您輸入的帳號已經被使用!</p>";
                
            } elseif ($_GET["signup"] == "success") {
                
                echo "<p class='success-message'>註冊成功!</p>";
                
            }
        }
    
    ?>
    <form action="signup_process.php" method="post">
        <p><input type="text" name="uid" placeholder="用戶帳號"></p>
        <p><input type="text" name="mail" placeholder="電子郵箱"></p>
        <p><input type="password" name="password" placeholder="密碼"></p>
        <p><input type="password" name="password-repeat" placeholder="再次輸入密碼"></p>
        <button type="sutmit" name="signup-submit">註 冊</button>
    </form>
  </main>

<?php require "footer.php"; ?>
